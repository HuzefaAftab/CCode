#include <iostream>
#include <string>
#include "clock.cpp"
using namespace std;

int main(){
int hour;
int second;
int minute;
cout<< "Enter the hours: ";
cin >> hour;
cout<< "Enter the minutes: ";
cin >> minute;
cout<< "Enter the seconds: ";
cin >> second;
 Clock clock{hour,minute,second};
if (hour || minute ||second < 10)
cout << "The time is " << clock.check(hour ,minute,second) << endl;
else
cout << "The time is " << clock.to_string() << endl;
return 0; 
}
