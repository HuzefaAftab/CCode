#include <iostream>
#include <string>
#include "clock.cpp"
using namespace std;

int main(){
int hour;
int second;
int minute;
while(second !=0){
cout<< "Enter the hours: ";
cin >> hour;
cout<< "Enter the minutes: ";
cin >> minute;
cout<< "Enter the seconds: ";
cin >> second;
if (hour > 23)
cout << "Invalid hours: " << hour << endl;
else if (minute > 59)
cout << "Invalid minutes: " << minute << endl;
else if (second  > 59 | second < 0)
cout << "Invalid seconds: " << second <<  endl;
}
 Clock clock{hour,minute,second};
cout << "The time is " << clock.to_string() << endl;
return 0; 
}

