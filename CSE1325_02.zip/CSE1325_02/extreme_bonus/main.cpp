#include <iostream>
#include <string>
#include "clock.cpp"
using namespace std;

int main(){
int hour;
int second,second2;
int minute;
cout<< "Enter the hours: ";
cin >> hour;
cout<< "Enter the minutes: ";
cin >> minute;
cout<< "Enter the seconds: ";
cin >> second;
Clock clock{hour,minute,second};
cout << "The time is " << clock.to_string() << endl;
while(second !=0){
cout <<"Enter elapsed seconds: ";
cin >> second2;
second = second+second2;
if (second > 60){
minute++;
second=minute-1;
if (minute > 60)
hour++;
}
 Clock clock{hour,minute,second};
cout << "The time is " << clock.to_string() << endl;
}
return 0;
}

