#include <iostream>
using namespace std;

class Clock {
public:
 Clock(int hour,int minute,int second): _hour{hour},_minute{minute},_second{second}{}
 string to_string(){
    return std::to_string(_hour)+":"+std::to_string(_minute)+":"+std::to_string(_second);
}
 string check(int _hour, int _minute, int _second){
if (_hour || _minute ||_second <10){
  return "0"+  std::to_string(_hour)+":"+"0"+std::to_string(_minute)+":"+"0"+std::to_string(_second);
}
}
private:
int _hour,_minute,_second;
   
};
